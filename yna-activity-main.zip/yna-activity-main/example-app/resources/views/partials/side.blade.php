<div class="sidebar">
    <ul class="nav nav-pills nav-flush flex-column text-center">
        <li class="nav-item-side">
            <a href="/create" class="nav-link-sidebar p-3" title="" data-bs-toggle="tooltip" data-bs-placement="right"
                data-bs-original-title="Add" onclick="toggleActiveLink(this)">
                <i class="fas fa-plus fa-lg"></i>
            </a>
        </li>
    </ul>
</div>
