    <div>

        <footer class="py-3">
            <ul class="nav justify-content-center border-top p-2 ">
                <li class="nav-item"><a href="/" class="nav-link px-3 text-body-secondary">Home</a></li>
                <li class="nav-item"><a href="/directory" class="nav-link px-3 text-body-secondary">Directory</a></li>
                <li class="nav-item"><a href="/create" class="nav-link px-3 text-body-secondary">Student+</a></li>
                <!---
                <li class="nav-item"><a href="/update" class="nav-link px-3 text-body-secondary">Profile Update</a></li>
                -->
            </ul>
            <p class="text-center"><a href="/" style="text-decoration: none; color: #6a1e84;"><b>© 2024
                        CourseTrack</b></a></p>
        </footer>
    </div>
